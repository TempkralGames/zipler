📃 Discord kanalıma katıl

🔰 https://discord.gg/JBCMkvejdv